<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\{AuthController, ProfileController, UserController, AdminController, BooksController, BookSetsController, BookPagesController};
use App\Http\Controllers\Frontend\{MaktabaController, BookViewerController, SearchController};

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//  Admin Panel Routs.
//Route::get('/admin',[AuthController::class, 'getLogin'])->name('getLogin');
Route::get('/admin/login',[AuthController::class, 'getLogin'])->name('getLogin');
Route::post('/admin/login',[AuthController::class, 'postLogin'])->name('postLogin');

// Admin Route Group
Route::group(['middleware' => ['admin_auth']], function(){
    Route::get('/admin/logout',[AuthController::class, 'logout'])->name('logout');
    Route::get('/admin/dashboard',[AdminController::class, 'dashboard'])->name('dashboard');
    Route::get('/admin/users', [UserController::class, 'index'])->name('users.index');
    Route::get('/admin/books', [AdminController::class, 'booksShow'])->name('books.show');
    Route::get('/admin/book-sets', [AdminController::class, 'booksetsShow'])->name('booksets.show');

    // Route definitions for Book Sets
    Route::get('/admin/bookset/add', [BookSetsController::class, 'index'])->name('bookset.add');
    Route::post('/admin/bookset/add', [BookSetsController::class, 'store']);
    Route::get('/admin/bookset/edit/{book_id}', [BookSetsController::class, 'edit']);
    Route::post('/admin/bookset/update/{book_id}', [BookSetsController::class, 'update']);
    Route::post('/admin/bookset/delete/{book_id}', [BookSetsController::class, 'delete']);

    // Route definitions for Books.
    Route::get('/admin/book-add', [BooksController::class, 'index'])->name('book.add');
    Route::post('/admin/book-add', [BooksController::class, 'store']);
    Route::get('/admin/book/edit/{book_id}', [BooksController::class, 'edit']);
    Route::post('/admin/book/update/{book_id}', [BooksController::class, 'update']);
    Route::post('/admin/book/delete/{book_id}', [BooksController::class, 'delete']);

    // Route definitions for book pages.
    Route::get('/admin/book/open/{book_id}', [BookPagesController::class, 'index'])->name('bookpage.add');
    Route::get('/admin/book/page/add/{book_id}', [BookPagesController::class, 'bookPage']);
    Route::post('/admin/book/page/add/', [BookPagesController::class, 'store']);
    Route::get('/admin/book/page/edit/{page_id}/{book_id}', [BookPagesController::class, 'edit']);
    Route::post('/admin/book/page/update/{page_id}', [BookPagesController::class, 'update']);
    Route::post('/admin/book/page/delete/{page_id}/{book_id}', [BookPagesController::class, 'delete']);
});


//  Frontend Routes.
Route::get('/',[MaktabaController::class, 'index'])->name('home');
Route::get('/book/open/{book_id}', [BookViewerController::class, 'index'])->name('bookpage.add');
//Route::get('/book/open/{book_id}?{page_no}', [BookViewerController::class, 'index'])->name('bookpage.add');
Route::get('/about',[MaktabaController::class, 'about'])->name('about');

Route::get('/search',[SearchController::class, 'index']);
Route::get('/search_text',[SearchController::class, 'search'])->name('search');
