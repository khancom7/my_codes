<?php

// My Custom Functions File

if (!function_exists("printArray")) {
    function printArray($data) : void {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}

