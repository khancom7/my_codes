<?php

// My Custom Functions File

if (!function_exists("printArray")) {
    function printArray($data) : void {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }

    if(!function_exists("mysqlConn")) {
        function mysqlConn($sql) {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "laravel_maktaba";

            $conn = new mysqli($servername, $username, $password, $dbname);
            mysqli_set_charset($conn, 'utf8');

            return $conn->query($sql);
        }
    }
}

