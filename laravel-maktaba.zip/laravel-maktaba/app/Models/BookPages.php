<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;

class BookPages extends Model
{
    use HasFactory, Searchable;

    protected $primaryKey = 'PageID';

    public function toSearchableArray()
    {
        return [
            'PageContent'  => $this->PageContent,
//            'PageNo'  => $this->PageNo,
        ];
    }
}
