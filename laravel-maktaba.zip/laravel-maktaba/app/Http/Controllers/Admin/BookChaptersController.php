<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Books;
use App\Models\BookChapters;
use Illuminate\Http\Request;

class BookChaptersController extends Controller
{
    public function index(Request $request) {

        $book_id = $request->book_id;

        $book_index = BookChapters::where("book_chapters.BookID", $book_id)->get();
        $book_title = Books::select('books.BookTitle', 'books.BookID')
            ->where('books.BookID', $book_id)->first();

//        $book_chapter_topics = BookChapterTopics::where("book_chapter_topics.ChapterID", $book_chapters->ChapterID)
//            ->get();

        $title = "پیغام بھیجیں";
        $url = url('/admin/book-index/add/chapter/');

        $data = compact('book_index', 'book_title', 'title', 'url');
        return view('admin.book-index')->with($data);
    }

    public function bookIndex($book_id) {
        $book_chapter = new BookChapters();

        $title = "پیغام بھیجیں";
        $url = url('/admin/book/index/add/');

        $data = compact('book_chapter', 'title', 'url', 'book_id');
        return view('admin.bookindex-add')->with($data);
    }

    public function store(Request $request) {

        $book_chapter = new BookChapters();

        $book_chapter->BookID = $request['book_id'];
        $book_chapter->ChapterName = $request['chapter_name'];
        $book_chapter->ChapterNo = $request['chapter_no'];
        $book_chapter->PageAssoc = $request['chapter_page_no'];

        $book_chapter->save();

        return redirect(url('admin/book/index/'.$request['book_id']));
    }

    public function edit($chapter_id)
    {
        $book_chapter = BookChapters::where('ChapterID', $chapter_id)->first();
//        printArray($book->toArray());die;
        $book_id = $book_chapter->BookID;
        $title = "پیغام بھیجیں";
        $url = url('/admin/book/index/update') . "/" . $chapter_id;

        $data = compact('title', 'url', 'book_chapter', 'book_id');
        return view('admin.bookindex-add')->with($data);
    }


    public function update(Request $request, $chapter_id) {

        $book_chapter = new BookChapters();
        $book_chapter = BookChapters::find($chapter_id);
//        printArray($book->toArray());die;
        $book_chapter->BookID = $request['book_id'];
        $book_chapter->ChapterName = $request['chapter_name'];
        $book_chapter->ChapterNo = $request['chapter_no'];
        $book_chapter->PageAssoc = $request['chapter_page_no'];

        $book_chapter->save();

        return redirect(url('admin/book/index/'.$request['book_id']));
    }

    public function delete($book_id, $chapter_id) {

        $book_chapter = BookChapters::where('ChapterID', $chapter_id)->delete();

        return redirect(url('admin/book/index/'. $book_id));
    }
}
