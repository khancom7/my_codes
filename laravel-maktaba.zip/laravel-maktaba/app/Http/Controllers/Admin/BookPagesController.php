<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Books;
use App\Models\BookSets;
use App\Models\BookPages;

class BookPagesController extends Controller
{
    public function index(Request $request, $book_id) {
        $book_pages = BookPages::select('book_pages.*', 'books.BookTitle')
            ->join('books', 'book_pages.BookID', '=', 'books.BookID')
            ->where('books.BookID', $book_id)
            ->orderBy('book_pages.PageNo', 'ASC')
            ->paginate(15);

        $book_title = Books::select('books.BookTitle', 'books.BookID')
            ->where('books.BookID', $book_id)->first();

        $data = compact('book_pages', 'book_title');
        return view('admin.bookpages')->with($data);
    }

    public function bookPage($id) {
        $page = new BookPages();
        $title = "پیغام بھیجیں";
        $url = url('/admin/book/page/add/');
        $book_id = $id;

        // this is example of inner join.
//        $book_sets = Books::select('books.*','book_sets.*')->latest('book_sets.BookSetID')            ->join('book_sets','books.BookSetID','=','book_sets.BookSetID')->get();

        $data = compact('page', 'title', 'url', 'book_id');
        return view('admin.bookpage-add')->with($data);
    }


    public function store(Request $request) {
//        $request->validate(
//            [
//                'name'  =>  'required',
//                'address'   =>  'required',
//                'feedback_message'   =>  'required',
//            ]
//        );

        $book = new BookPages();

        $book->BookID = $request['book_id'];
        $book->PageTitle = $request['page_title'];
        $book->PageNo = $request['page_no'];
        $book->PageOrder = $request['page_order'];
        $book->PageContent = $request['page_content'];
        $book->PageHashiyah = $request['page_hashiyah'];

        $book->save();

        return redirect(url('/admin/book/open/'.$book->BookID));
    }

    public function edit($page_id, $book_id)
    {
        $page = BookPages::where('PageID', $page_id)->first();

//        printArray($book_content->toArray());die;
        $title = "پیغام بھیجیں";
        $url = url('/admin/book/page/update') . "/" . $page_id;

        $data = compact('page', 'title', 'url', 'book_id');
        return view('admin.bookpage-add')->with($data);
    }


    public function update(Request $request, $id)
    {
        $book = new BookPages();

        $book = BookPages::where('PageID', $id)->first();
        $book->PageTitle = $request['page_title'];
        $book->PageNo = $request['page_no'];
        $book->PageOrder = $request['page_order'];
        $book->PageContent = $request['page_content'];
        $book->PageHashiyah = $request['page_hashiyah'];

        $book->save();

        return redirect(url('/admin/book/open/'.$book->BookID));
    }


    public function delete($page_id, $book_id) {
//        echo $page_id. "book". $book_id;die;
        $book = BookPages::where('PageID', $page_id)->delete();

        return redirect(url('/admin/book/open/' . $book_id));
    }
}
