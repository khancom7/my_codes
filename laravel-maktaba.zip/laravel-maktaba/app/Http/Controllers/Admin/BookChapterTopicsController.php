<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BookChapters;
use App\Models\BookChapterTopics;
use Illuminate\Http\Request;

class BookChapterTopicsController extends Controller
{
    public function index($chapter_id) {
        $book_chapter_topic = new BookChapterTopics();

        $title = "پیغام بھیجیں";
        $url = url('/admin/book/index-topic/add/');

        $data = compact('book_chapter_topic', 'title', 'url', 'chapter_id');
        return view('admin.bookindex-topic-add')->with($data);
    }

    public function store(Request $request) {

        $book_chapter_topic = new BookChapterTopics();

        $book_chapter_topic->ChapterID = $request['chapter_id'];
        $book_chapter_topic->TopicName = $request['topic_name'];
        $book_chapter_topic->TopicOrder = $request['topic_order'];
        $book_chapter_topic->PageAssoc = $request['topic_page_assoc'];

        $book_id = BookChapters::where("book_chapters.ChapterID", $book_chapter_topic->ChapterID)->first();

        $book_chapter_topic->save();

        return redirect(url('admin/book/index/'.$book_id->BookID));
    }

    public function edit($chapter_topic_id)
    {
        $book_chapter_topic = BookChapterTopics::where('TopicID', $chapter_topic_id)->first();
//        printArray($book->toArray());die;
        $chapter_id = $book_chapter_topic->ChapterID;
        $title = "پیغام بھیجیں";
        $url = url('/admin/book/index-topic/update') . "/" . $chapter_topic_id;

        $data = compact('title', 'url', 'book_chapter_topic', 'chapter_id');
        return view('admin.bookindex-topic-add')->with($data);
    }


    public function update(Request $request, $chapter_topic_id)
    {
        $book_chapter_topic = BookChapterTopics::where('ChapterID', $chapter_topic_id)->first();
//        printArray($book->toArray());die;
        $book_chapter_topic->ChapterID = $request['chapter_id'];
        $book_chapter_topic->TopicName = $request['topic_name'];
        $book_chapter_topic->TopicOrder = $request['topic_order'];
        $book_chapter_topic->PageAssoc = $request['topic_page_assoc'];

        $book_id = BookChapters::where("book_chapters.ChapterID", $book_chapter_topic->ChapterID)->first();

        $book_chapter_topic->save();

        return redirect(url('admin/book/index/'.$book_id->BookID));
    }

    public function delete($book_id, $chapter_topic_id) {

        $book_chapter = BookChapterTopics::where('TopicID', $chapter_topic_id)->delete();

        return redirect(url('admin/book/index/'. $book_id));
    }
}
