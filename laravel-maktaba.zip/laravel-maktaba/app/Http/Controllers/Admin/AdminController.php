<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Books;
use App\Models\BookSets;

class AdminController extends Controller
{
    public function dashboard() {
        $books = Books::all()->count();
        $book_sets = BookSets::all()->count();

        $data = compact('books', 'book_sets');

        return view('admin.dashboard')->with($data);
    }
    public function booksShow() {
        $books = Books::paginate(15);
        return view('admin.books',['books'=>$books]);
    }
    public function booksetsShow() {
        $book_sets = BookSets::all();
        return view('admin.booksets',['book_sets'=>$book_sets]);
    }
}
