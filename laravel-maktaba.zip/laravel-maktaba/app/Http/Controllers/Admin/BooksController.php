<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Books;
use App\Models\BookSets;

class BooksController extends Controller
{
    public function index() {

        $book = new Books();
        $book_sets = BookSets::all();

        $title = "پیغام بھیجیں";
        $url = url('/admin/book-add');

        // this is example of inner join.
//        $book_sets = Books::select('books.*','book_sets.*')->latest('book_sets.BookSetID')            ->join('book_sets','books.BookSetID','=','book_sets.BookSetID')->get();

        $data = compact('book', 'book_sets', 'title', 'url');
        return view('admin.book-add')->with($data);
    }

    public function store(Request $request) {
//        $request->validate(
//            [
//                'name'  =>  'required',
//                'address'   =>  'required',
//                'feedback_message'   =>  'required',
//            ]
//        );

        $book = new Books();

        $book->BookSetID = $request['book_set_id'];
        $book->BookTitle = $request['book_title'];
        $book->BookAuthor = $request['book_author'];
        $book->BookJildNo = $request['book_jild_no'];
        $book->BookNoOfPages = $request['book_no_of_pages'];
        $book->BookNoOfChapters = $request['book_no_of_chapters'];

        $book->save();

        return redirect(route('books.show'));
    }


    public function edit($id)
    {
        $book = Books::where('BookID', $id)->first();
        $book_sets = BookSets::all();
//        printArray($book->toArray());die;
        $title = "پیغام بھیجیں";
        $url = url('/admin/book/update/') . "/" . $id;

        $data = compact('book', 'book_sets', 'title', 'url');
        return view('admin.book-add')->with($data);
    }


    public function update(Request $request, $id)
    {
        $book = Books::where('BookID', $id)->first();
//        printArray($book->toArray());die;
        $book->BookSetID = $request['book_set_id'];
        $book->BookTitle = $request['book_title'];
        $book->BookAuthor = $request['book_author'];
        $book->BookJildNo = $request['book_jild_no'];
        $book->BookNoOfPages = $request['book_no_of_pages'];
        $book->BookNoOfChapters = $request['book_no_of_chapters'];

        $book->save();

        return redirect(route('books.show'));
    }

    public function delete($id) {
//        echo $id;die;
        $data = [];
        $book = Books::where('BookID', $id)->delete();

        return redirect(route('books.show'));
    }
}
