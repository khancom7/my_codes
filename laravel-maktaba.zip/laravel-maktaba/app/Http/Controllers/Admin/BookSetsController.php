<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Books;
use App\Models\BookSets;

class BookSetsController extends Controller
{
    public function index() {
        $book_sets = new BookSets();

        $title = "پیغام بھیجیں";
        $url = url('/admin/bookset/add');

        // this is example of inner join.
//        $book_sets = Books::select('books.*','book_sets.*')->latest('book_sets.BookSetID')            ->join('book_sets','books.BookSetID','=','book_sets.BookSetID')->get();

        $data = compact('book_sets', 'title', 'url');
        return view('admin.bookset-add')->with($data);
    }


    public function store(Request $request) {
//        $request->validate(
//            [
//                'name'  =>  'required',
//                'address'   =>  'required',
//                'feedback_message'   =>  'required',
//            ]
//        );

        $book = new BookSets();

        $book->BookSetName = $request['bookset_name'];

        $book->save();

        return redirect(route('booksets.show'));
    }


    public function edit($id)
    {
        $book_sets = BookSets::where('BookSetID', $id)->first();
//        printArray($book->toArray());die;
        $title = "پیغام بھیجیں";
        $url = url('/admin/bookset/update/') . "/" . $id;

        $data = compact('book_sets', 'title', 'url');
        return view('admin.bookset-add')->with($data);
    }


    public function update(Request $request, $id)
    {
        $book_sets = BookSets::where('BookSetID', $id)->first();
//        printArray($book->toArray());die;
        $book_sets->BookSetName = $request['bookset_name'];

        $book_sets->save();

        return redirect(route('booksets.show'));
    }

    public function delete($id) {
//        echo $id;die;
        $data = [];
        $feedback = BookSets::where('BookSetID', $id)->delete();

        return redirect(route('booksets.show'));
    }
}
