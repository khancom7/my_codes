<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Books;
use App\Models\BookPages;
use Illuminate\Http\Request;

class MaktabaController extends Controller
{
    public function index() {
        $books = Books::paginate(1);

        $data = compact('books');
        return view('frontend.home')->with($data);
    }

    public function about() {

        return view('frontend.about');
    }
}
