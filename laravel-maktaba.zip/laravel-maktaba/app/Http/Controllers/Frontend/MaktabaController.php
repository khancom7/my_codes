<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BookContent;

class MaktabaController extends Controller
{
    public function index() {
        $contents = BookContent::all();
        return view('frontend.home',['contents'=>$contents]);
    }

    public function about() {

        return view('frontend.about');
    }
}
