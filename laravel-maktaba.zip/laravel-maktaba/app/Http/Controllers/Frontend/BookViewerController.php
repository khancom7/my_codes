<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\BookChapterTopics;
use App\Models\BookPages;
use App\Models\BookChapters;
use Illuminate\Http\Request;

class BookViewerController extends Controller
{
    public function index (Request $request) {

        $book_id = $request['book_id'];
//        $page_no = $request['page_no'];

        $book_pages = BookPages::select('book_pages.*', 'books.BookTitle')
            ->orderBy('book_pages.PageOrder', 'ASC')
            ->join('books', 'book_pages.BookID', '=', 'books.BookID')
            ->where('books.BookID', $book_id)
            ->get();

        $page_count = BookPages::select('book_pages.*')
            ->where('book_pages.BookID', $book_id)
            ->count();

        $book_index = BookChapters::select('book_chapters.*')
            ->where('book_chapters.BookID', $book_id)
            ->get();

        $data = compact('book_pages', 'page_count', 'book_index');

        return view('frontend.book-reader')->with($data);
    }

    public function showIndex(Request $request) {
        $book_id = $request->book_id;

        $book_index = BookChapters::select('book_chapters.*')
            ->where('book_chapters.BookID', $book_id)
            ->get();


//        $book_chapter_topics = BookChapterTopics::select('book_chapter_topics.*')
//            ->where('book_chapter_topics.ChapterID', 1)
//            ->get();

        $data = compact('book_index');

        return view('frontend.book-index')->with($data);
    }
}
