<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\BookPages;

class BookViewerController extends Controller
{
    public function index ($book_id) {
        $book_pages = BookPages::select('book_pages.*', 'books.BookTitle')
            ->orderBy('book_pages.PageOrder', 'ASC')
            ->join('books', 'book_pages.BookID', '=', 'books.BookID')
            ->where('books.BookID', $book_id)
            ->get();

        $page_count = BookPages::select('book_pages.*')
            ->where('book_pages.BookID', $book_id)
            ->count();

        $data = compact('book_pages', 'page_count');

        return view('frontend.book-reader')->with($data);
    }
}
