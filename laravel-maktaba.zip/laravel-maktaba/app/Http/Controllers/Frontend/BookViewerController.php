<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\BookPages;

class BookViewerController extends Controller
{
    public function index ($book_id) {
        $book_pages = BookPages::select('book_pages.*', 'books.BookTitle')
            ->orderBy('book_pages.PageNo', 'ASC')
            ->join('books', 'book_pages.BookID', '=', 'books.BookID')
            ->where('books.BookID', $book_id)
            ->get();

        $data = compact('book_pages');

        return view('frontend.book-reader')->with($data);
    }
}
