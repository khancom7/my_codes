<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Books;
use App\Models\BookPages;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function index() {

        $pages = new BookPages();
        return view('frontend.search-form');
    }

    public function search(Request $request) {
        $book_name = array();
        if ($request->filled('search')) {
            $pages = BookPages::search($request->search)->get();
            foreach ($pages as $key => $page) {
//                $book_id[$key] = $page->BookID;
                $book_name[$key] = Books::select('books.BookTitle', 'books.BookID')
                    ->where('books.BookID', $page->BookID)->first();
            }
        } else {
            $pages = BookPages::get();
        }

        $search_text = $request->search;
        $data = compact('pages', 'book_name', 'search_text');
        return view('frontend.search-result')->with($data);
    }
}
