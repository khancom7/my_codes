<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('book_chapter_topics', function (Blueprint $table) {
            $table->id('TopicID');
            $table->integer('ChapterID');
            $table->string('TopicName');
            $table->integer('TopicOrder');
            $table->integer('PageAssoc');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('book_chapter_topics');
    }
};
