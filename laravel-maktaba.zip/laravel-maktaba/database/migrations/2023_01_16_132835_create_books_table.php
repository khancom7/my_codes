<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
            $table->id('BookID');
//            $table->foreignId('BookSetID')->constrained('book_sets')->default(1);
            $table->integer('BookSetID');
            $table->string('BookTitle')->nullable();
            $table->string('BookAuthor')->nullable();
            $table->integer('BookJildNo')->nullable();
            $table->integer('BookNoOfPages')->nullable();
            $table->integer('BookNoOfChapters')->nullable();
            $table->string('BookImage')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('books');
    }
};
