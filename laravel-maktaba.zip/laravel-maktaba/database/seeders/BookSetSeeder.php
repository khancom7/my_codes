<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\BookSets;
use Faker\Factory as Faker;

class BookSetSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('ar_SA');

        for($i = 1; $i <= 33; $i++) {
            $book_set = new BookSets;

            $book_set->BookSetName = $faker->name;

            $book_set->save();
        }
    }
}
