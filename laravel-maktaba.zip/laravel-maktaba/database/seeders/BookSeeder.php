<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use App\Models\Books;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('ar_SA');

        for($i = 1; $i <= 3; $i++) {
            $book = new Books;

            $book->BookTitle = $faker->name;
            $book->BookJildNo = $faker->numberBetween(1, 13);
            $book->BookAuthor = $faker->name;

            $book->save();
        }
    }
}
