<!DOCTYPE html>
<html lang="ur" dir="rtl">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Full Width Pics - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/admin-assets/img/favicon.ico')); ?>" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('/admin-assets/css/bootstrap.rtl.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/admin-assets/css/bootstrap-icons.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('/admin-assets/css/admin-style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/admin-assets/css/adminlte/adminlte.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('page-style'); ?>
</head>
<body>
<!-- Responsive navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">مکتبہ ختم نبوت</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav float-end mb-2 mb-lg-0">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link active">ڈیش بورڈ</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('books.show')); ?>" class="nav-link">کتابیں</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('booksets.show')); ?>" class="nav-link">جلدیں</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link">لاگ آوٗٹ</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Header - set the background image for the header in the line below-->








<section>
    <div class="container-fluid">
        <!-- Content section-->
        <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</section>



<!-- Image element - set the background image for the header in the line below-->





<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</footer>
<!-- Jquery core JS-->
<script src="<?php echo e(asset('/admin-assets/js/jquery.min.js')); ?>"></script>

<!-- jQuery UI 1.11.4 -->

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->



<!-- Bootstrap 5 -->
<script src="<?php echo e(asset('/admin-assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin-assets/js/adminlte/adminlte.js')); ?>"></script>
<!-- Core theme JS-->
<script src="<?php echo e(asset('/admin-assets/js/scripts.js')); ?>"></script>

<?php echo $__env->yieldContent('page-script'); ?>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/master.blade.php ENDPATH**/ ?>