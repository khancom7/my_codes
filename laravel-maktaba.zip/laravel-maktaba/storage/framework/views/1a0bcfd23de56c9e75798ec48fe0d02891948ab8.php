<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Full Width Pics - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/admin-assets/img/favicon.ico')); ?>" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('/admin-assets/css/bootstrap.rtl.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/admin-assets/css/bootstrap-icons.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('/admin-assets/css/admin-style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/admin-assets/css/adminlte/adminlte.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('page-style'); ?>
</head>
<body>
<!-- Responsive navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#!">مکتبہ ختم نبوت</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav float-end mb-2 mb-lg-0">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link active">ڈیش بورڈ</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('books.show')); ?>" class="nav-link">کتابیں</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('booksets.show')); ?>" class="nav-link">جلدیں</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link">لاگ آوٗٹ</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Header - set the background image for the header in the line below-->








<section>
    <div class="container-fluid">
        <div class="row row-cols-2">
            <div class="col-md-3 px-0">
                <!-- sidebar -->
                <div class="d-flex flex-column flex-shrink-0 p-1 bg-light" style="width: 280px;">
                    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
                        <svg class="bi pe-none me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
                        <span class="fs-4">فہرست</span>
                    </a>
                    <hr>

                    <!-- Accordion -->
                    <div class="accordion accordion-flush" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                    کتب سیٹ
                                </button>
                            </h2>
                            <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <strong>عنوان نمبر ۱</strong>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                    کتابیں
                                </button>
                            </h2>
                            <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <strong>تمام کتابیں دیکھیں</strong>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                    Accordion Item #3
                                </button>
                            </h2>
                            <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <strong>عنوان نمبر ۳</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Accordion ends-->

                    <!-- sidebar items starts -->
                    <!--<ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item">
                            <a href="#" class="nav-link active" aria-current="page">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#home"/></svg>
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#table"/></svg>
                                Orders
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#grid"/></svg>
                                Products
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#people-circle"/></svg>
                                Customers
                            </a>
                        </li>
                    </ul>-->
                    <!-- sidebar items ends -->
                    <hr>

                    <!-- sidebar dropdown starts -->
                    <!-- <div class="dropdown">
                        <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://github.com/mdo.png" alt="" width="32" height="32" class="rounded-circle me-2">
                            <strong>mdo</strong>
                        </a>
                        <ul class="dropdown-menu text-small shadow">
                            <li><a class="dropdown-item" href="#">New project...</a></li>
                            <li><a class="dropdown-item" href="#">Settings</a></li>
                            <li><a class="dropdown-item" href="#">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">Sign out</a></li>
                        </ul>
                    </div>-->
                    <!-- sidebar dropdown ends -->

                </div> <!-- my row's col-md- ends -->
            </div>
            <div class="col-md-9">
                <!-- Content section-->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</section>



<!-- Image element - set the background image for the header in the line below-->





<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</footer>
<!-- Jquery core JS-->
<script src="<?php echo e(asset('/admin-assets/js/jquery.min.js')); ?>"></script>

<!-- jQuery UI 1.11.4 -->

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->



<!-- Bootstrap 5 -->
<script src="<?php echo e(asset('/admin-assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/admin-assets/js/adminlte/adminlte.js')); ?>"></script>
<!-- Core theme JS-->
<script src="<?php echo e(asset('/admin-assets/js/scripts.js')); ?>"></script>

<?php echo $__env->yieldContent('page-script'); ?>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/master.blade.php ENDPATH**/ ?>