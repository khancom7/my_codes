<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="float-start my-3 col-md-6">
                                <h1 class="card-title float-start" style="font-size: 2em;">کتاب: <?php echo e($book_title->BookTitle); ?></h1>
                            </div>
                            <div class="card-tools float-end col-md-6">
                                <div class="input-group input-group-sm">
                                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default">
                                            Search <i class="bi bi-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="float-start mt-4">
                                    <a href="/admin/book/index/<?php echo e($book_title->BookID); ?>" class="btn btn-success btn-lg">فہرست</a>
                                </div>
                                <?php echo e($book_pages->links()); ?>

                            </div>
                            <div class="col-md-6">
                                <div class="float-end mt-4">
                                    <a href="/admin/book/page/add/<?php echo e($book_title->BookID); ?>" class="btn btn-success btn-lg">نیا صفحہ</a>
                                </div>
                            </div>
                        </div>


                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-responsive table-hover text-nowrap">
                            <thead>
                            <tr>
                                <th scope="col">Number</th>
                                <th scope="col">Pages</th>
                                <th scope="col">Page No</th>
                                <th colspan="2" scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $book_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><div class="float-start"><?php echo Str::limit($row->PageContent, 95); ?></div></td>
                                    <td><?php echo e($row->PageNo); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/admin/book/page/edit/'.$row->PageID)); ?>/<?php echo e($row->BookID); ?>" class="btn btn-outline-primary float-end bi bi-pencil-square">&nbsp;&nbsp;&nbsp;Edit</a>
                                    </td>
                                    <td>
                                        <form action="/admin/book/page/delete/<?php echo e($row->PageID); ?>/<?php echo e($row->BookID); ?>" method="POST">
                                            
                                            <?php echo e(csrf_field()); ?>

                                            <input type="submit" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/bookpages.blade.php ENDPATH**/ ?>