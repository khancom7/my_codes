<?php $__env->startSection('content'); ?>

    <div class="card col-md-10">
<div class="card-body">
    <form action="<?php echo e($url); ?>" class="form-horizontal" method="POST">
        <?php echo e(csrf_field()); ?>


        <input type="text" class="form-control" name="book_id" value="<?php echo e($book_id); ?>" hidden />
        <div class="form-group row">
            <div class="col-sm-6">
                <label for="page_title" class="col-sm-3 text-center">صفحہ کا ٹائیٹل: </label>
                <input type="text" class="form-control" name="page_title" value="<?php echo e($page->PageTitle); ?>">
                <span class="text-danger">
                        <?php $__errorArgs = ['page_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="page_no" class="col-sm-3 text-center">صفحہ کا نمبر: </label>
                <input type="number" class="form-control" name="page_no" value="<?php echo e($page->PageNo); ?>">
                <span class="text-danger">
                        <?php $__errorArgs = ['page_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="page_order" class="col-sm-3 text-center">صفحہ کی ترتیب: </label>
                <input type="number" class="form-control" name="page_order" value="<?php echo e($page->PageOrder); ?>">
                <span class="text-danger">
                        <?php $__errorArgs = ['page_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
            </div>
        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <div class="mb-3">
                    <label for="page_content" class="form-label">عبارت: </label>
                    <textarea class="form-control" id="page_tpage_contentext" name="page_content" rows="3"><?php echo e($page->PageContent); ?></textarea>
                </div>
                <span class="text-danger">
                        <?php $__errorArgs = ['page_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
            </div>
        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <div class="mb-3">
                    <label for="page_hashiyah" class="form-label">حاشیہ: </label>
                    <textarea class="form-control" id="page_hashiyah" name="page_hashiyah" rows="3"><?php echo e($page->PageHashiyah); ?></textarea>
                </div>
                <span class="text-danger">
                        <?php $__errorArgs = ['page_hashiyah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
            </div>
        </div>

        <div class="mb-3">

        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-12 text-center">
                <input type="submit" class="btn btn-info" value="بھیجیں">
            </div>
        </div>
    </form>
</div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/bookpage-add.blade.php ENDPATH**/ ?>