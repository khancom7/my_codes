<?php $__env->startSection('content'); ?>

<table class="table table-responsive">
    <thead>
    <tr>
        <th scope="col">نمبر</th>
        <th scope="col">عنوان</th>
        <th scope="col">صفحہ نمبر</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $book_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="table-info">
            
            <td><?php echo e($row->ChapterNo); ?></td>
            <td>
                <h4>
                    <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>#p<?php echo e($row->PageAssoc); ?>" style="text-decoration: none;">
                        <?php echo e($row->ChapterName); ?>

                    </a>
                </h4>
                <table class="table table-responsive">
                    <thead>
                    <th></th>
                    <th></th>
                    </thead>
                    <tbody>
                <?php
                    $sql = "SELECT * FROM `book_chapter_topics` WHERE  `ChapterID` = ". $row->ChapterID;
                                       $result = mysqlConn($sql);
                       while($strow = $result->fetch_assoc()) {
                            ?>
                    <tr class="table-success">
                        <td>
                            <h5>
                                <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>#p<?php echo e($strow['PageAssoc']); ?>">
                                    <h6><?php echo e($strow['TopicName']); ?></h6>
                                </a>
                            </h5>

                        </td>
                        <td>
                            <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>#p<?php echo e($strow['PageAssoc']); ?>">
                                <h6><?php echo e($strow['PageAssoc']); ?></h6>
                            </a>
                        </td>

                    </tr>
                <?php
						}
                ?>
                    </tbody>
                </table>



            </td>

            <td>
                <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>#p<?php echo e($row->PageAssoc); ?>" style="text-decoration: none;">
                    <?php echo e($row->PageAssoc); ?>

                </a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/book-index.blade.php ENDPATH**/ ?>