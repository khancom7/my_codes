<h1>Users Page.</h1>
<?php /**PATH E:\xampp\htdocs\projects\laravel-admin-lte\resources\views/admin/users/index.blade.php ENDPATH**/ ?>