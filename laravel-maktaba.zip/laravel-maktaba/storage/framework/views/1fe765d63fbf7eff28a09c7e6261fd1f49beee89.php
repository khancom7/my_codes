<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row mt-3">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="col-lg-3 col-3">
                <!-- small box -->
                <div class="small-box bg-blue">
                    <div class="inner text-start">
                        <h3><?php echo e($book_sets); ?></h3>
                        <p>کل کتب سیٹس</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="/admin/book-sets/" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-3">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner text-start">
                        <h3><?php echo e($books); ?></h3>
                        <p>موجودہ کتابوں کی تعداد</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="/admin/books/" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-md-1"></div>

    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>