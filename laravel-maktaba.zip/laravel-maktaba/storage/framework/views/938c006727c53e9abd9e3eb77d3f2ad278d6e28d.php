<?php $__env->startSection('content'); ?>

<div class="col-md-12 align-items-center">
    <div class="card">
        <div class="card-header">
            <h1 class="card-title text-center" style="font-family: myCustomUrduFont3; font-size: 5em;">مکتبہ ختم نبوت</h1>
        </div>
        <div class="card-body table-responsive">
            <h5 class="card-title">ختم نبوت کی کتابیں یونی کوڈ میں</h5>
            <hr>
            <div class="row">
                <?php echo e($books->links()); ?>

            </div>
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>

                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td>
                            <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>" style="text-decoration: none;">
                                <?php echo e($row->BookTitle); ?>

                            </a>
                        </td>
                        <td><?php echo e($row->BookAuthor); ?></td>
                        <td>
                            <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>" class="btn btn-outline-primary float-start">کھولیں</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/home.blade.php ENDPATH**/ ?>