<?php $__env->startSection('content'); ?>

<div class="col-md-4 align-items-center">
    <div class="card" style="width: 60rem;">
        <div class="card-header">
            <h1 class="card-title" style="font-family: myCustomUrduFont3; font-size: 6em;">مکتبہ ختم نبوت</h1>
        </div>
        <div class="card-body table-responsive">
            <h5 class="card-title">ختم نبوت کی کتابیں یونی کوڈ میں</h5>
            <hr>
            <div class="row">
                <?php echo e($books->links()); ?>

            </div>
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>Number</th>
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($row->BookTitle); ?></td>
                        <td><?php echo e($row->BookAuthor); ?></td>
                        <td>
                            <a href="<?php echo e(url('book/open/'.$row->BookID)); ?>" class="btn btn-outline-primary float-start bi bi-book-fill">&nbsp;&nbsp;&nbsp;Open</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/home.blade.php ENDPATH**/ ?>