<?php $__env->startSection('content'); ?>

    <div>
        <h3>تلاش: </h3>
        <h3><?php echo e($search_text); ?></h3>
    </div>
<table class="table table-bordered data-table">
    <thead>
    <tr>
        <th>Page No</th>
        <th>Book</th>
        <th>Text</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($page->PageNo); ?></td>
            <td><?php echo e($book_name[$key]->BookTitle); ?></td>
            <td>
                <a class="text-decoration-none" href="/book/open/<?php echo e($page->BookID); ?>#p<?php echo e($page->PageNo); ?>">
                    <?php echo Str::limit($page->PageContent, 95); ?>

                </a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/search-result.blade.php ENDPATH**/ ?>