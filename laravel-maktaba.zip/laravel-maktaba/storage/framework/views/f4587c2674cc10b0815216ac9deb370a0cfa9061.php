<!DOCTYPE html>
<html lang="ur" dir="rtl">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Full Width Pics - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('frontend-assets/img/favicon.ico')); ?>" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('frontend-assets/css/bootstrap.rtl.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend-assets/css/bootstrap-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend-assets/css/sidebar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend-assets/css/style.css')); ?>" rel="stylesheet" />
    <?php echo $__env->yieldContent('page-style'); ?>
</head>
<body>
<!-- Responsive navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="/">مکتبہ ختم نبوت</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav float-end mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link active" aria-current="page" href="/">ہوم پیج</a></li>
                <li class="nav-item"><a class="nav-link active" aria-current="page" href="/search"><i class="bi bi-search"></i>&nbsp;&nbsp; تلاش کریں </a></li>
                <li class="nav-item"><a class="nav-link" href="/about">ہمارے بارے میں</a></li>
                <li class="nav-item"><a class="nav-link" href="/contact-us">رابطہ کریں</a></li>
            </ul>
        </div>
    </div>
</nav>
<!-- Header - set the background image for the header in the line below-->
<header class="frontend-header pb-5 pt-0 bg-image-full">
    <div class="text-center mb-5 mt-0">
        <img class="img-fluid rounded-circle mb-4" src="<?php echo e(asset('frontend-assets/img/logo.png')); ?>" alt="..." />
        <h1 class="text-white mb-5 fw-bolder maktaba-main-title">مکتبہ ختم نبوت</h1>
        <p class="text-white-50 mb-0 fs-5">عالمی مجلس تحفظ ختم نبوت</p>
    </div>
</header>

<section>
    <div class="container-fluid">
        <!-- Content section-->
        <?php echo $__env->yieldContent('content'); ?>




        </div>
    </div>
</section>



<!-- Image element - set the background image for the header in the line below-->
    
    
    
    

<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</footer>
<!-- Bootstrap core JS-->
<script src="<?php echo e(asset('frontend-assets/js/jquery.min.js')); ?>"></script>

<!-- jQuery UI 1.11.4 -->

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->



<!-- Bootstrap 5 -->
<script src="<?php echo e(asset('frontend-assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Core theme JS-->
<script src="<?php echo e(asset('frontend-assets/js/scripts.js')); ?>"></script>

<?php echo $__env->yieldContent('page-script'); ?>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/master.blade.php ENDPATH**/ ?>