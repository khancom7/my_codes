<?php
//    printArray($pages);die;
?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-center">Scout Text Search</h2>
        <form method="get" action="<?php echo e(route('search')); ?>">
            <div class="mb-3">
                <label for="search"class="form-label">Email address</label>

                <input type="text"
                       class="form-control"
                       name="search"
                       value="<?php echo e(request()->get('search')); ?>"
                       placeholder="Search Text" />
                <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <table class="table table-bordered data-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($page->PageNo); ?></td>
                    <td><?php echo e($page->PageContent); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/search.blade.php ENDPATH**/ ?>