<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Log in</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('/admin-assets/css/fontawesome-free/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('/admin-assets/css/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/admin-assets/css/adminlte/adminlte.css')); ?>">
    <link href="<?php echo e(asset('/admin-assets/css/admin-style.css')); ?>" rel="stylesheet" />
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="login-logo">
        <a href="#" style="font-family: myCustomUrduFont"><strong>مکتبہ </strong><b>ایڈمن </b>پینل</a>
    </div>
    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <?php if(session('error')): ?>
                <div class="text-danger text-center">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="text-success text-center">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            <p class="login-box-msg">Sign in to start your session</p>

            <form action="<?php echo e(route('postLogin')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-1">
                    <input name="email" type="email" class="form-control" placeholder="ای میل">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-group mb-1">
                    <input name="password" type="password" class="form-control" placeholder="پاس ورڈ">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="row">
                    <div class="col-8">






                    </div>
                    <!-- /.col -->
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">داخل ہو جائے</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo e(asset('/admin-assets/js/jquery.min.js')); ?>"></script>
<!-- Bootstrap 5 -->
<script src="<?php echo e(asset('/admin-assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('/admin-assets/js/adminlte/adminlte.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>