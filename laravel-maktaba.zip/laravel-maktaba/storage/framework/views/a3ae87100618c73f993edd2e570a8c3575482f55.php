<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-10">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">تمام موجودہ سیٹ</h3>

                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="float-end">
                                <a href="<?php echo e(route('bookset.add')); ?>" class="btn btn-success float-end">نیا سیٹ</a>
                            </div>
                        </div>
                    </div>
                    <?php echo e($book_sets->links()); ?>

                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap">
                            <thead>
                            <tr>
                                <th>Number</th>
                                <th>Book Sets</th>
                                <th colspan="2"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $book_sets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($row->BookSetName); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/admin/bookset/edit/'.$row->BookSetID)); ?>" class="btn btn-outline-primary float-end bi bi-pencil-square">&nbsp;&nbsp;&nbsp;Edit</a>
                                    </td>
                                    <td>
                                        <form action="/admin/bookset/delete/<?php echo e($row->BookSetID); ?>" method="POST">
                                            
                                            <?php echo e(csrf_field()); ?>

                                            <input type="submit" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/admin/booksets.blade.php ENDPATH**/ ?>