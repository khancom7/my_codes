<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-10">

                <?php $__currentLoopData = $book_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="card-header">
                            <span id="p<?php echo e($row->PageNo); ?>"></span>
                            <h5 class="card-title"><?php echo e($row->BookTitle); ?></h5>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div>
                                <h5 class="card-title float-end"><?php echo e($row->PageTitle); ?></h5>
                            </div>
                            <div>
                                <p class="text-center">---------------------------------------</p>
                            </div>
                            <div>
                                <p class="card-text">
                                    <?php echo $row->PageContent; ?>

                                </p>
                            </div>
                        </div> <!-- /.card-body -->
                        <div class="card-footer text-muted text-center">
                            صفحہ نمبر: <?php echo e($row->PageNo); ?>

                        </div>
                    </div> <!-- /.card -->
                    <span class="mb-1">&nbsp;</span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/book-reader.blade.php ENDPATH**/ ?>