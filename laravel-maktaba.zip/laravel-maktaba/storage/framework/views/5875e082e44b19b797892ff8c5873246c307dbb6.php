<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-10">
                <h6>کل صفحات: <?php echo e($page_count); ?></h6>
                <?php $__currentLoopData = $book_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card border border-success">
                        <div class="card-header bg-dark text-white border border-info">
                            <div class="row">
                                <div class="col-md-4 d-inline-block">
                                    <span id="p<?php echo e($row->PageNo); ?>"></span>
                                    <h4 class="card-title mt-3"><?php echo e($row->BookTitle); ?></h4>
                                </div>
                                <div class="col-md-4 d-inline-block align-self-center">
                                    <h3 class="card-title text-center mt-3">
                                        <i class="bi bi-book-half"></i>
                                    </h3>
                                </div>
                                <div class="col-md-4 d-inline-block">
                                    <h6 class="card-title float-end mt-4">{- <?php echo e($row->PageTitle); ?> -}</h6>
                                </div>
                            </div>




                        </div>
                        <!-- /.card-header -->
                        <div class="card-body py-0">




                            <div class="card-text" style="font-size: 1.2em; line-height: 2.5em; word-spacing: 0.1em;">
                                <?php echo $row->PageContent; ?>

                            </div>
                            <div class="text-center">
                                <div class="d-inline-block p-2 border border-1 rounded-pill">
                                    صفحہ نمبر: <?php echo e($row->PageNo); ?>

                                </div>
                            </div>
                        </div> <!-- /.card-body -->
                        <div class="card-footer text-muted text-center">
                            <div class="text-start">
                                <?php echo $row->PageHashiyah; ?>

                            </div>
                        </div>
                    </div> <!-- /.card -->
                    <span class="mb-1">&nbsp;</span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\projects\laravel-maktaba\resources\views/frontend/book-reader.blade.php ENDPATH**/ ?>