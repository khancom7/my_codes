<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Full Width Pics - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="{{ asset('/admin-assets/img/favicon.ico') }}" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="{{ asset('/admin-assets/css/bootstrap.rtl.css') }}" rel="stylesheet" />
    <link href="{{ asset('/admin-assets/css/bootstrap-icons.css') }}" rel="stylesheet" />
{{--    <link href="{{ asset('/admin-assets/css/sidebar.css') }}" rel="stylesheet" />--}}
    <link href="{{ asset('/admin-assets/css/admin-style.css') }}" rel="stylesheet" />
    <link href="{{ asset('/admin-assets/css/adminlte/adminlte.css') }}" rel="stylesheet" />
    @yield('page-style')
</head>
<body>
<!-- Responsive navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#!">مکتبہ ختم نبوت</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav float-end mb-2 mb-lg-0">
                <li class="nav-item">
                    <a href="{{ route('dashboard') }}" class="nav-link active">ڈیش بورڈ</a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('books.show') }}" class="nav-link">کتابیں</a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('booksets.show') }}" class="nav-link">جلدیں</a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('logout') }}" class="nav-link">لاگ آوٗٹ</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Header - set the background image for the header in the line below-->
{{--<header class="pb-5 pt-0 bg-image-full">--}}
{{--    <div class="text-center mb-5 mt-0">--}}
{{--        <img class="img-fluid rounded-circle mb-4" src="{{ asset('admin-assets/img/logo.png') }}" alt="..." />--}}
{{--        <h1 class="text-success mb-5 fw-bolder maktaba-main-title">مکتبہ ختم نبوت</h1>--}}
{{--        <p class="text-dark-50 mb-0 fs-5">عالمی مجلس تحفظ ختم نبوت</p>--}}
{{--    </div>--}}
{{--</header>--}}

<section>
    <div class="container-fluid">
        <div class="row row-cols-2">
            <div class="col-md-3 px-0">
                <!-- sidebar -->
                <div class="d-flex flex-column flex-shrink-0 p-1 bg-light" style="width: 280px;">
                    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
                        <svg class="bi pe-none me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
                        <span class="fs-4">فہرست</span>
                    </a>
                    <hr>

                    <!-- Accordion -->
                    <div class="accordion accordion-flush" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                    کتب سیٹ
                                </button>
                            </h2>
                            <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <strong>عنوان نمبر ۱</strong>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                    کتابیں
                                </button>
                            </h2>
                            <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <strong>تمام کتابیں دیکھیں</strong>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                    Accordion Item #3
                                </button>
                            </h2>
                            <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <strong>عنوان نمبر ۳</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Accordion ends-->

                    <!-- sidebar items starts -->
                    <!--<ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item">
                            <a href="#" class="nav-link active" aria-current="page">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#home"/></svg>
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#table"/></svg>
                                Orders
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#grid"/></svg>
                                Products
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link link-dark">
                                <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#people-circle"/></svg>
                                Customers
                            </a>
                        </li>
                    </ul>-->
                    <!-- sidebar items ends -->
                    <hr>

                    <!-- sidebar dropdown starts -->
                    <!-- <div class="dropdown">
                        <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://github.com/mdo.png" alt="" width="32" height="32" class="rounded-circle me-2">
                            <strong>mdo</strong>
                        </a>
                        <ul class="dropdown-menu text-small shadow">
                            <li><a class="dropdown-item" href="#">New project...</a></li>
                            <li><a class="dropdown-item" href="#">Settings</a></li>
                            <li><a class="dropdown-item" href="#">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">Sign out</a></li>
                        </ul>
                    </div>-->
                    <!-- sidebar dropdown ends -->

                </div> <!-- my row's col-md- ends -->
            </div>
            <div class="col-md-9">
                <!-- Content section-->
                @yield('content')
            </div>
        </div>
    </div>
</section>



<!-- Image element - set the background image for the header in the line below-->
{{--<div class="py-5 bg-image-full" style="background-image: url('https://source.unsplash.com/4ulffa6qoKA/1200x800')">--}}
{{--    <!-- Put anything you want here! The spacer below with inline CSS is just for demo purposes!-->--}}
{{--    <div style="height: 20rem"></div>--}}
{{--</div>--}}

<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</footer>
<!-- Jquery core JS-->
<script src="{{ asset('/admin-assets/js/jquery.min.js') }}"></script>

<!-- jQuery UI 1.11.4 -->
{{--<script src="{{ asset('admin-assets/js/jquery-ui.min.js') }}"></script>--}}
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
{{--<script>--}}
{{--    $.widget.bridge('uibutton', $.ui.button)--}}
{{--</script>--}}
<!-- Bootstrap 5 -->
<script src="{{ asset('/admin-assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('/admin-assets/js/adminlte/adminlte.js') }}"></script>
<!-- Core theme JS-->
<script src="{{ asset('/admin-assets/js/scripts.js') }}"></script>

@yield('page-script')

</body>
</html>
