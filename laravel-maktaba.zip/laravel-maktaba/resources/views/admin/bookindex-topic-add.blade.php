@extends('admin.master')
{{--@php--}}
{{--    echo "hello,";die;--}}
{{--@endphp--}}
@section('content')

    <div class="card col-md-10">
<div class="card-body">
    <form action="{{$url}}" class="form-horizontal" method="POST">
        {{ csrf_field() }}

        <input type="text" class="form-control" name="chapter_id" value="{{ $chapter_id }}" hidden />
        <div class="form-group row">
            <div class="col-sm-6">
                <label for="topic_name" class="col-sm-3 text-center">عنوان کا نام: </label>
                <input type="text" class="form-control" name="topic_name" value="{{$book_chapter_topic->TopicName}}">
                <span class="text-danger">
                        @error('topic_name')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="topic_order" class="col-sm-3 text-center">عنوان نمبر: </label>
                <input type="number" class="form-control" name="topic_order" value="{{$book_chapter_topic->TopicOrder}}">
                <span class="text-danger">
                        @error('topic_order')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="topic_page_assoc" class="col-sm-3 text-center">عنوان کا صفحہ نمبر: </label>
                <input type="number" class="form-control" name="topic_page_assoc" value="{{$book_chapter_topic->PageAssoc}}">
                <span class="text-danger">
                        @error('topic_page_assoc')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>
        <div class="mb-3">

        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-12 text-center">
                <input type="submit" class="btn btn-info" value="بھیجیں">
            </div>
        </div>
    </form>
</div>
    </div>

@endsection

@section('page-script')
    <script type="text/javascript" src="{{ asset('/admin-assets/js/tinymce/tinymce.min.js') }}" ></script>
    <script>
        tinymce.init({
            selector: '#page_content', // change this according to your HTML
            toolbar: 'language',
            width:	'800',
            height: 600,
            directionality : 'rtl',
        });
        tinymce.init({
            selector: '#page_hashiyah', // change this according to your HTML
            toolbar: 'language',
            width:	'600',
            directionality : 'rtl',
        });
    </script>
@endsection
