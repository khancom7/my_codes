@extends('admin.master')

@php
//    printArray($book_chapters->toArray());die;
@endphp

@section('content')
        <div class="row">
            <div class="col-12">

                <div class="card" style="width: 60rem;">
                    <div class="card-header">

                        <div class="col-md-8 float-start">
                            <div class="row mb-2">
                                <h1 class="card-title text-start my-2" style="font-size: 2em;">فہرست: {{ $book_title->BookTitle }}</h1>
                            </div>
{{--                            <div class="row">{{ $books->links() }}</div>--}}
                        </div>
                        <div class="card-tools float-end col-md-4">
                            <div class="float-end mt-4">
                                <a href="/admin/book/index/add/{{ $book_title->BookID }}" class="btn btn-success float-end">نیا باب</a>
                            </div>
                        </div>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">نمبر</th>
                                <th scope="col">عنوان</th>
                                <th scope="col">صفحہ نمبر</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($book_index as $key => $row)
                                <tr>
                                    {{--                        <td>{{ $key+1 }}</td>--}}
                                    <td>
                                        <a href="{{url('/admin/book/index/add'.$row->BookID)}}" class="btn btn-outline-success btn-sm float-end bi bi-plus-square">&nbsp;&nbsp;&nbsp;عنوان
                                        </a>
                                    </td>
                                    <td>{{$row->ChapterNo}}</td>
                                    <td>
                                        <h4>
                                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                                                {{$row->ChapterName}}
                                            </a>
                                        </h4>
                                        <table class="table">
                                            <thead>
                                            <th></th>
                                            <th></th>
                                            </thead>
                                            <tbody>
                                            @php
                                                $sql = "SELECT * FROM `book_chapter_topics` WHERE  `ChapterID` = ". $row->ChapterID;
                                                                   $result = mysqlConn($sql);
                                                   while($strow = $result->fetch_assoc()) {
                                            @endphp
                                            <tr>
                                                <td>
                                                    <h5>
                                                        <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">
                                                            <h6>{{ $strow['TopicName'] }}</h6>
                                                        </a>
                                                    </h5>

                                                </td>
                                                <td>
                                                    <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">
                                                        <h6>{{ $strow['PageAssoc'] }}</h6>
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="{{url('/admin/book/edit/'.$row->BookID)}}" class="btn btn-outline-primary btn-sm float-end bi bi-pencil-square">&nbsp;&nbsp;&nbsp;Edit</a>
                                                </td>
                                                <td>
                                                    <form action="/admin/book/delete/{{$row->BookID}}" method="POST" class="float-start">
                                                        {{--                            {{method_field('DELETE')}}--}}
                                                        {{csrf_field()}}
                                                        <input type="submit" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger btn-sm" value="Delete">
                                                    </form>
                                                </td>
                                            </tr>
                                            @php
                                                }
                                            @endphp
                                            </tbody>
                                        </table>
                                        {{--                @foreach ($book_chapter_topics as $tkey => $trow)--}}
                                        {{--                    {{ $trow->TopicName }}--}}
                                        {{--                @endforeach--}}
                                    </td>

                                    <td>
                                        <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                                            {{$row->PageAssoc}}
                                        </a>
                                    </td>
                                    <td>
                                        <a href="{{url('/admin/book/index/edit/'.$row->ChapterID)}}" class="btn btn-outline-primary float-end bi bi-pencil-square">&nbsp;&nbsp;&nbsp;Edit</a>
                                    </td>
                                    <td>
                                        <form action="/admin/book/index/delete/{{ $row->BookID }}/{{$row->ChapterID}}" method="POST">
                                            {{--                            {{method_field('DELETE')}}--}}
                                            {{csrf_field()}}
                                            <input type="submit" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>

@endsection
