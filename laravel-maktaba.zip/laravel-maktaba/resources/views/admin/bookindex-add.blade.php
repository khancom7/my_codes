@extends('admin.master')
{{--@php--}}
{{--    echo "hello,";die;--}}
{{--@endphp--}}
@section('content')

    <div class="card col-md-10">
<div class="card-body">
    <form action="{{$url}}" class="form-horizontal" method="POST">
        {{ csrf_field() }}

        <input type="text" class="form-control" name="book_id" value="{{ $book_id }}" hidden />
        <div class="form-group row">
            <div class="col-sm-6">
                <label for="chapter_name" class="col-sm-3 text-center">باب کا نام: </label>
                <input type="text" class="form-control" name="chapter_name" value="{{$book_chapter->ChapterName}}">
                <span class="text-danger">
                        @error('chapter_name')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="chapter_no" class="col-sm-3 text-center">باب نمبر: </label>
                <input type="number" class="form-control" name="chapter_no" value="{{$book_chapter->ChapterNo}}">
                <span class="text-danger">
                        @error('chapter_no')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="chapter_page_no" class="col-sm-3 text-center">باب کا صفحہ نمبر: </label>
                <input type="number" class="form-control" name="chapter_page_no" value="{{$book_chapter->PageAssoc}}">
                <span class="text-danger">
                        @error('chapter_page_no')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>
        <div class="mb-3">

        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-12 text-center">
                <input type="submit" class="btn btn-info" value="بھیجیں">
            </div>
        </div>
    </form>
</div>
    </div>

@endsection

@section('page-script')
    <script type="text/javascript" src="{{ asset('/admin-assets/js/tinymce/tinymce.min.js') }}" ></script>
    <script>
        tinymce.init({
            selector: '#page_content', // change this according to your HTML
            toolbar: 'language',
            width:	'800',
            height: 600,
            directionality : 'rtl',
        });
        tinymce.init({
            selector: '#page_hashiyah', // change this according to your HTML
            toolbar: 'language',
            width:	'600',
            directionality : 'rtl',
        });
    </script>
@endsection
