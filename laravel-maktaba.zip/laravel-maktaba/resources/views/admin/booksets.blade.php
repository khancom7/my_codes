@extends('admin.master')

@section('content')

        <div class="row">
            <div class="col-10">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">تمام موجودہ سیٹ</h3>

                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="float-end">
                                <a href="{{ route('bookset.add') }}" class="btn btn-success float-end">نیا سیٹ</a>
                            </div>
                        </div>
                    </div>
                    {{ $book_sets->links() }}
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap">
                            <thead>
                            <tr>
                                <th>Number</th>
                                <th>Book Sets</th>
                                <th colspan="2"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($book_sets as $key => $row)
                                <tr>
                                    <td>{{ $key+1 }}</td>
                                    <td>{{$row->BookSetName}}</td>
                                    <td>
                                        <a href="{{url('/admin/bookset/edit/'.$row->BookSetID)}}" class="btn btn-outline-primary float-end bi bi-pencil-square">&nbsp;&nbsp;&nbsp;Edit</a>
                                    </td>
                                    <td>
                                        <form action="/admin/bookset/delete/{{$row->BookSetID}}" method="POST">
                                            {{--                            {{method_field('DELETE')}}--}}
                                            {{csrf_field()}}
                                            <input type="submit" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>

@endsection
