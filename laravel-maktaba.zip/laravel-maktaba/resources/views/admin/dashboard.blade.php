@extends('admin.master')

{{--@php--}}
{{--    printArray($books);die;--}}
{{--@endphp--}}

@section('content')
    <!-- Main row -->
    <div class="row mt-3">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="col-lg-3 col-3">
                <!-- small box -->
                <div class="small-box bg-blue">
                    <div class="inner text-start">
                        <h3>{{ $book_sets }}</h3>
                        <p>کل کتب سیٹس</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="/admin/book-sets/" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-3">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner text-start">
                        <h3>{{ $books }}</h3>
                        <p>موجودہ کتابوں کی تعداد</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="/admin/books/" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-md-1"></div>

    </div>
    <!-- /.row (main row) -->
@endsection
