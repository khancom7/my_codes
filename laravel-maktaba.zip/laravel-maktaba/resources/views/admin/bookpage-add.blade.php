@extends('admin.master')
{{--@php--}}
{{--    printArray($url);die;--}}
{{--@endphp--}}
@section('content')

    <div class="card col-md-10">
<div class="card-body">
    <form action="{{$url}}" class="form-horizontal" method="POST">
        {{ csrf_field() }}

        <input type="text" class="form-control" name="book_id" value="{{ $book_id }}" hidden />
        <div class="form-group row">
            <div class="col-sm-6">
                <label for="page_title" class="col-sm-3 text-center">صفحہ کا ٹائیٹل: </label>
                <input type="text" class="form-control" name="page_title" value="{{$page->PageTitle}}">
                <span class="text-danger">
                        @error('page_title')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="page_no" class="col-sm-3 text-center">صفحہ کا نمبر: </label>
                <input type="number" class="form-control" name="page_no" value="{{$page->PageNo}}">
                <span class="text-danger">
                        @error('page_no')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <label for="page_order" class="col-sm-3 text-center">صفحہ کی ترتیب: </label>
                <input type="number" class="form-control" name="page_order" value="{{$page->PageOrder}}">
                <span class="text-danger">
                        @error('page_order')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <div class="mb-3">
                    <label for="page_content" class="form-label">عبارت: </label>
                    <textarea class="form-control" id="page_content" name="page_content" rows="3">{{$page->PageContent}}</textarea>
                </div>
                <span class="text-danger">
                        @error('page_content')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-6">
                <div class="mb-3">
                    <label for="page_hashiyah" class="form-label">حاشیہ: </label>
                    <textarea class="form-control" id="page_hashiyah" name="page_hashiyah" rows="3">{{$page->PageHashiyah}}</textarea>
                </div>
                <span class="text-danger">
                        @error('page_hashiyah')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="mb-3">

        </div>
        <div class="form-group row pt-2">
            <div class="col-sm-12 text-center">
                <input type="submit" class="btn btn-info" value="بھیجیں">
            </div>
        </div>
    </form>
</div>
    </div>

@endsection

@section('page-script')
    <script type="text/javascript" src="{{ asset('/admin-assets/js/tinymce/tinymce.min.js') }}" ></script>
    <script>
        tinymce.init({
            selector: '#page_content', // change this according to your HTML
            toolbar: 'language',
            width:	'800',
            height: 600,
            directionality : 'rtl',
        });
        tinymce.init({
            selector: '#page_hashiyah', // change this according to your HTML
            toolbar: 'language',
            width:	'600',
            directionality : 'rtl',
        });
    </script>
@endsection
