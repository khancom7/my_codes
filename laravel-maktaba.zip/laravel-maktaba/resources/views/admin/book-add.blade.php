@extends('admin.master')
{{--@php--}}
{{--    printArray($book_sets);die;--}}
{{--@endphp--}}
@section('content')

    <div class="card col-md-10">
<div class="card-body">
    <form action="{{$url}}" class="form-horizontal" method="POST">
        {{ csrf_field() }}

        <div class="form-group row">
            <label for="book_title" class="col-sm-3 text-center">سیٹ منتخب کریں: </label>
            <div class="col-sm-6">
                <select class="form-select" aria-label="Default select example" name="book_set_id">
                    <option selected>کوئی نہیں</option>
                    @foreach($book_sets as $key => $val)
                        <option value="{{ $val->BookSetID }}">{{ $val->BookSetName }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="form-group row">
            <label for="book_title" class="col-sm-3 text-center">کتاب کا ٹائیٹل: </label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="book_title" value="{{$book->BookTitle}}">
                {{--                    <input type="text" class="form-control" name="name" value="{{isset($feedback) ? $customer->Name : ""}}">--}}
                <span class="text-danger">
                        @error('book_title')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <label for="book_author" class="col-sm-3 text-center">مصنف كا نام: </label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="book_author" value="{{$book->BookAuthor}}">
                <span class="text-danger">
                        @error('book_author')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <label for="book_jild_no" class="col-sm-3 text-center">کتاب کا جلد نمبر: </label>
            <div class="col-sm-6">
                <input type="number" class="form-control" name="book_jild_no" value="{{$book->BookJildNo}}">
                <span class="text-danger">
                        @error('book_jild_no')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>
        <div class="form-group row pt-2">
            <label for="book_no_of_pages" class="col-sm-3 text-center">صفحات کی تعداد: </label>
            <div class="col-sm-6">
                <input type="number" class="form-control" name="book_no_of_pages" value="{{$book->BookNoOfPages}}">
                <span class="text-danger">
                        @error('book_no_of_pages')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>
        <div class="form-group row pt-2">
            <label for="book_no_of_chapters" class="col-sm-3 text-center">ابواب کی تعداد: </label>
            <div class="col-sm-6">
                <input type="number" class="form-control" name="book_no_of_chapters" value="{{$book->BookNoOfChapters}}">
                <span class="text-danger">
                        @error('book_no_of_chapters')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="mb-3">


        </div>
        {{-- <div class="form-group row">
            <label for="" class="col-sm-3 text-right">Gender</label>
            <div class="col-sm-3">
                <input type="radio" name="gender" value="m"> Male
                <input type="radio" name="gender" value="f"> Female
            </div>
        </div> --}}
        <div class="form-group row pt-2">
            <div class="col-sm-12 text-center">
                <input type="submit" class="btn btn-info" value="بھیجیں">
            </div>
        </div>
    </form>
</div>
    </div>

@endsection
