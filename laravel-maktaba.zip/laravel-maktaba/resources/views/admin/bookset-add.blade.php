@extends('admin.master')
{{--@php--}}
{{--    printArray($book_sets);die;--}}
{{--@endphp--}}
@section('content')

    <div class="card col-md-10">
<div class="card-body">
    <form action="{{$url}}" class="form-horizontal" method="POST">
        {{ csrf_field() }}

        <div class="form-group row">
            <label for="bookset_name" class="col-sm-3 text-center">سیٹ کا ٹائیٹل: </label>
            <div class="col-sm-6">
                <input type="text" class="form-control" name="bookset_name" value="{{$book_sets->BookSetName}}">
                {{--                    <input type="text" class="form-control" name="name" value="{{isset($feedback) ? $customer->Name : ""}}">--}}
                <span class="text-danger">
                        @error('bookset_name')
                    {{$message}}
                    @enderror
                    </span>
            </div>
        </div>

        <div class="form-group row pt-2">
            <div class="col-sm-12 text-center">
                <input type="submit" class="btn btn-info" value="بھیجیں">
            </div>
        </div>
    </form>
</div>
    </div>

@endsection
