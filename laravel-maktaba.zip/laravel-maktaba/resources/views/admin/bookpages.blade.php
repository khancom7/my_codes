@extends('admin.master')

@section('content')

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="float-start my-3 col-md-6">
                                <h1 class="card-title float-start" style="font-size: 2em;">کتاب: {{ $book_title->BookTitle }}</h1>
                            </div>
                            <div class="card-tools float-end col-md-6">
                                <div class="input-group input-group-sm">
                                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default">
                                            Search <i class="bi bi-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="float-start mt-4">
                                    <a href="/admin/book/index/{{ $book_title->BookID }}" class="btn btn-success btn-lg">فہرست</a>
                                </div>
                                {{ $book_pages->links() }}
                            </div>
                            <div class="col-md-6">
                                <div class="float-end mt-4">
                                    <a href="/admin/book/page/add/{{ $book_title->BookID }}" class="btn btn-success btn-lg">نیا صفحہ</a>
                                </div>
                            </div>
                        </div>


                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-responsive table-hover text-nowrap">
                            <thead>
                            <tr>
                                <th scope="col">Number</th>
                                <th scope="col">Pages</th>
                                <th scope="col">Page No</th>
                                <th colspan="2" scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($book_pages as $key => $row)
                                <tr>
                                    <th scope="row">{{ $key+1 }}</th>
                                    <td><div class="float-start">{!! Str::limit($row->PageContent, 95) !!}</div></td>
                                    <td>{{$row->PageNo}}</td>
                                    <td>
                                        <a href="{{url('/admin/book/page/edit/'.$row->PageID)}}/{{ $row->BookID }}" class="btn btn-outline-primary float-end bi bi-pencil-square">&nbsp;&nbsp;&nbsp;Edit</a>
                                    </td>
                                    <td>
                                        <form action="/admin/book/page/delete/{{$row->PageID}}/{{$row->BookID}}" method="POST">
                                            {{--                            {{method_field('DELETE')}}--}}
                                            {{csrf_field()}}
                                            <input type="submit" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>

@endsection
