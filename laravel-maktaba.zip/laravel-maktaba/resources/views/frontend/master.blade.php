<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Full Width Pics - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="{{ asset('frontend-assets/img/favicon.ico') }}" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="{{ asset('frontend-assets/css/bootstrap.rtl.css') }}" rel="stylesheet" />
    <link href="{{ asset('frontend-assets/css/bootstrap-icons.css') }}" rel="stylesheet" />
    <link href="{{ asset('frontend-assets/css/sidebar.css') }}" rel="stylesheet" />
    <link href="{{ asset('frontend-assets/css/style.css') }}" rel="stylesheet" />
    @yield('page-style')
</head>
<body>
<!-- Responsive navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="/">مکتبہ ختم نبوت</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav float-end mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link active" aria-current="page" href="/">ہوم پیج</a></li>
                <li class="nav-item"><a class="nav-link" href="/about">ہمارے بارے میں</a></li>
                <li class="nav-item"><a class="nav-link" href="/contact-us">رابطہ کریں</a></li>
            </ul>
        </div>
    </div>
</nav>
<!-- Header - set the background image for the header in the line below-->
<header class="frontend-header pb-5 pt-0 bg-image-full">
    <div class="text-center mb-5 mt-0">
        <img class="img-fluid rounded-circle mb-4" src="{{ asset('frontend-assets/img/logo.png') }}" alt="..." />
        <h1 class="text-white mb-5 fw-bolder maktaba-main-title">مکتبہ ختم نبوت</h1>
        <p class="text-white-50 mb-0 fs-5">عالمی مجلس تحفظ ختم نبوت</p>
    </div>
</header>

<section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10 mt-4">
                <!-- Content section-->
                @yield('content')
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
</section>



<!-- Image element - set the background image for the header in the line below-->
    {{--<div class="py-5 bg-image-full" style="background-image: url('https://source.unsplash.com/4ulffa6qoKA/1200x800')">--}}
    {{--    <!-- Put anything you want here! The spacer below with inline CSS is just for demo purposes!-->--}}
    {{--    <div style="height: 20rem"></div>--}}
    {{--</div>--}}

<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</footer>
<!-- Bootstrap core JS-->
<script src="{{ asset('frontend-assets/js/jquery.min.js') }}"></script>

<!-- jQuery UI 1.11.4 -->
{{--<script src="{{ asset('admin-assets/js/jquery-ui.min.js') }}"></script>--}}
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
{{--<script>--}}
{{--    $.widget.bridge('uibutton', $.ui.button)--}}
{{--</script>--}}
<!-- Bootstrap 5 -->
<script src="{{ asset('frontend-assets/js/bootstrap.bundle.min.js') }}"></script>
<!-- Core theme JS-->
<script src="{{ asset('frontend-assets/js/scripts.js') }}"></script>

@yield('page-script')

</body>
</html>
