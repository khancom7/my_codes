@extends('admin.master')
{{--@php--}}
{{--    printArray($book_pages->toArray());die;--}}
{{--@endphp--}}
@section('content')
        <div class="row">
            <div class="col-10">

                @foreach($book_pages as $key => $row)
                    <div class="card">
                        <div class="card-header">
                            <span id="p{{ $row->PageNo }}"></span>
                            <h5 class="card-title">{{ $row->BookTitle }}</h5>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div>
                                <h5 class="card-title float-end">{{ $row->PageTitle }}</h5>
                            </div>
                            <div>
                                <p class="text-center">---------------------------------------</p>
                            </div>
                            <div>
                                <p class="card-text">
                                    {!! $row->PageContent !!}
                                </p>
                            </div>
                        </div> <!-- /.card-body -->
                        <div class="card-footer text-muted text-center">
                            صفحہ نمبر: {{ $row->PageNo }}
                        </div>
                    </div> <!-- /.card -->
                    <span class="mb-1">&nbsp;</span>
                @endforeach
            </div>
        </div>

@endsection
