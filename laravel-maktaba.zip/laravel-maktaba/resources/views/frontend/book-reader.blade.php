@extends('frontend.master')
{{--@php--}}
{{--    printArray($book_pages->toArray());die;--}}
{{--@endphp--}}
@section('content')
        <div class="row">
            <div class="col-10">
                <h6>کل صفحات: {{ $page_count }}</h6>
                @foreach($book_pages as $key => $row)
                    <div class="card border border-success">
                        <div class="card-header bg-dark text-white border border-info">
                            <div class="row">
                                <div class="col-md-4 d-inline-block">
                                    <span id="p{{ $row->PageNo }}"></span>
                                    <h4 class="card-title mt-3">{{ $row->BookTitle }}</h4>
                                </div>
                                <div class="col-md-4 d-inline-block align-self-center">
                                    <h3 class="card-title text-center mt-3">
                                        <i class="bi bi-book-half"></i>
                                    </h3>
                                </div>
                                <div class="col-md-4 d-inline-block">
                                    <h6 class="card-title float-end mt-4">{- {{ $row->PageTitle }} -}</h6>
                                </div>
                            </div>




                        </div>
                        <!-- /.card-header -->
                        <div class="card-body py-0">
{{--                            <div class="mb-3">--}}
{{--                                <p class="float-start d-inline-block">----------</p>--}}
{{--                                <p class="float-end d-inline-block">------------</p>--}}
{{--                            </div>--}}
                            <div class="card-text" style="font-size: 1.2em; line-height: 2.5em; word-spacing: 0.1em;">
                                {!! $row->PageContent !!}
                            </div>
                            <div class="text-center">
                                <div class="d-inline-block p-2 border border-1 rounded-pill">
                                    صفحہ نمبر: {{ $row->PageNo }}
                                </div>
                            </div>
                        </div> <!-- /.card-body -->
                        <div class="card-footer text-muted text-center">
                            <div class="text-start">
                                {!! $row->PageHashiyah !!}
                            </div>
                        </div>
                    </div> <!-- /.card -->
                    <span class="mb-1">&nbsp;</span>
                @endforeach
            </div>
        </div>

@endsection
