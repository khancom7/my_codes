@extends('frontend.master')
{{--@php--}}
{{--    printArray($book_pages->toArray());die;--}}
{{--@endphp--}}
@section('content')
    <div class="accordion" id="accordionExample">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <h5 class="text-danger"style="font-family: myCustomUrduFont3, sans-serif; font-size: 2em;">
                        کتاب کی فہرست
                    </h5>
                </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <table class="table table-striped table-responsive">
                        <thead>
                        <tr>
                            <th scope="col">عنوان</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($book_index as $key => $row)
                            <tr class="table-light">
                                {{--                        <td>{{ $key+1 }}</td>--}}
                                <td>
                                    <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                                        <h5 class="text-success" style="font-family: myCustomUrduFont10, sans-serif;">
                                            {{$row->ChapterName}}
                                        </h5>
                                    </a>
                                    <table class="table table-borderless table-responsive">
                                        <thead>
                                        <th></th>
                                        <th></th>
                                        </thead>
                                        <tbody>
                                        @php
                                            $sql = "SELECT * FROM `book_chapter_topics` WHERE  `ChapterID` = ". $row->ChapterID;
                                                 $result = mysqlConn($sql);
                                                 while($strow = $result->fetch_assoc()) {
                                        @endphp
                                        <tr class="table-light">
                                            <td>
                                                <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}" style="text-decoration: none;">
                                                    <h6 class="text-decoration-none text-secondary ps-5" style="font-family: myCustomUrduFont11, sans-serif; font-size: 1.2em;">
                                                        {{ $strow['TopicName'] }}
                                                    </h6>
                                                </a>

                                            </td>
                                            <td></td>
                                            {{--                                    <td>--}}
                                            {{--                                        <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">--}}
                                            {{--                                            <h6>{{ $strow['PageAssoc'] }}</h6>--}}
                                            {{--                                        </a>--}}
                                            {{--                                    </td>--}}

                                        </tr>
                                        @php
                                            }
                                        @endphp
                                        </tbody>
                                    </table>
                                    {{--                @foreach ($book_chapter_topics as $tkey => $trow)--}}
                                    {{--                    {{ $trow->TopicName }}--}}
                                    {{--                @endforeach--}}
                                </td>

                                {{--                        <td>--}}
                                {{--                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">--}}
                                {{--                                {{$row->PageAssoc}}--}}
                                {{--                            </a>--}}
                                {{--                        </td>--}}
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
{{--                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">--}}
{{--                </button>--}}
            </div>

        </div>
    </div>
    <div class="row">


        <!-- this is book index in side nav -->
        <!-- book index starts -->

{{--        <div class="col-md-2">--}}
{{--            <table class="table table-responsive">--}}
{{--                <thead>--}}
{{--                <tr>--}}
{{--                    <th scope="col">عنوان</th>--}}
{{--                </tr>--}}
{{--                </thead>--}}
{{--                <tbody>--}}
{{--                @foreach($book_index as $key => $row)--}}
{{--                    <tr class="table-light">--}}
{{--                        --}}{{--                        <td>{{ $key+1 }}</td>--}}
{{--                        <td>--}}
{{--                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">--}}
{{--                                <h5 class="text-success">--}}
{{--                                    {{$row->ChapterName}}--}}
{{--                                </h5>--}}
{{--                            </a>--}}
{{--                            <table class="table table-responsive">--}}
{{--                                <thead>--}}
{{--                                <th></th>--}}
{{--                                <th></th>--}}
{{--                                </thead>--}}
{{--                                <tbody>--}}
{{--                                @php--}}
{{--                                   $sql = "SELECT * FROM `book_chapter_topics` WHERE  `ChapterID` = ". $row->ChapterID;--}}
{{--                                        $result = mysqlConn($sql);--}}
{{--                                        while($strow = $result->fetch_assoc()) {--}}
{{--                                @endphp--}}
{{--                                <tr class="table-light">--}}
{{--                                    <td>--}}
{{--                                        <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}" style="text-decoration: none;">--}}
{{--                                            <h6 class="text-decoration-none text-secondary">{{ $strow['TopicName'] }}</h6>--}}
{{--                                        </a>--}}

{{--                                    </td>--}}
{{--                                    <td>--}}
{{--                                        <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">--}}
{{--                                            <h6>{{ $strow['PageAssoc'] }}</h6>--}}
{{--                                        </a>--}}
{{--                                    </td>--}}

{{--                                </tr>--}}
{{--                                @php--}}
{{--                                    }--}}
{{--                                @endphp--}}
{{--                                </tbody>--}}
{{--                            </table>--}}
{{--                            --}}{{--                @foreach ($book_chapter_topics as $tkey => $trow)--}}
{{--                            --}}{{--                    {{ $trow->TopicName }}--}}
{{--                            --}}{{--                @endforeach--}}
{{--                        </td>--}}

{{--                        <td>--}}
{{--                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">--}}
{{--                                {{$row->PageAssoc}}--}}
{{--                            </a>--}}
{{--                        </td>--}}
{{--                    </tr>--}}
{{--                @endforeach--}}
{{--                </tbody>--}}
{{--            </table>--}}
{{--        </div>--}}

        <!-- book index ends -->

        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="mt-3">
                <h6>کل صفحات: {{ $page_count }}</h6>
            </div>
            @foreach($book_pages as $key => $row)
                <div class="card border border-success">
                    <div class="card-header bg-dark text-white">
                        <div class="col-md-12">
                            <div class="col-md-4 d-inline-block float-start">
                                <span id="p{{ $row->PageNo }}"></span>
                                <h4 class="card-title mt-3">{{ $row->BookTitle }}</h4>
                            </div>
                            <div class="col-md-4 d-inline-block align-self-center">
                                <h3 class="card-title text-center mt-3">
                                    <i class="bi bi-book-half"></i>
                                </h3>
                            </div>
                            <div class="col-md-4 d-inline-block float-end">
                                <h6 class="card-title float-end mt-3">{- {{ $row->PageTitle }} -}</h6>
                            </div>
                        </div>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body py-0 px-2">
                        {{--                            <div class="mb-3">--}}
                        {{--                                <p class="float-start d-inline-block">----------</p>--}}
                        {{--                                <p class="float-end d-inline-block">------------</p>--}}
                        {{--                            </div>--}}
                        <div class="card-text" style="font-size: 1.2em; line-height: 2.5em; word-spacing: 0.1em;">
                            {!! $row->PageContent !!}
                        </div>
                        <div class="text-center">
                            <div class="d-inline-block p-2 border border-1 rounded-pill">
                                صفحہ نمبر: {{ $row->PageNo }}
                            </div>
                        </div>
                    </div> <!-- /.card-body -->
                    <div class="card-footer text-muted text-center">
                        <div class="text-start">
                            {!! $row->PageHashiyah !!}
                        </div>
                    </div>
                </div> <!-- /.card -->
                <span class="mb-1">&nbsp;</span>
            @endforeach
        </div>
        <div class="col-md-1"></div>
    </div>
    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="bi bi-arrow-up-square"></i></button>

@endsection
