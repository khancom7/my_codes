@extends('frontend.master')
{{--@php--}}
{{--    printArray($book_pages->toArray());die;--}}
{{--@endphp--}}
@section('content')
    <div class="row">
        <div class="col-md-2">
            <table class="table table-responsive">
                <thead>
                <tr>
                    <th scope="col">عنوان</th>
                    <th scope="col">صفحہ نمبر</th>
                </tr>
                </thead>
                <tbody>
                @foreach($book_index as $key => $row)
                    <tr class="table-light">
                        {{--                        <td>{{ $key+1 }}</td>--}}
                        <td>
                            <h6>
                                <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                                    {{$row->ChapterName}}
                                </a>
                            </h6>
                            <table class="table table-responsive">
                                <thead>
                                <th></th>
                                <th></th>
                                </thead>
                                <tbody>
                                @php
//                                    $servername = "localhost";
//                                    $username = "root";
//                                    $password = "";
//                                    $dbname = "laravel_maktaba";
//
//                                    $conn = new mysqli($servername, $username, $password, $dbname);
//                                    mysqli_set_charset($conn, 'utf8');
                                   $sql = "SELECT * FROM `book_chapter_topics` WHERE  `ChapterID` = ". $row->ChapterID;
                                        $result = mysqlConn($sql);
                                        while($strow = $result->fetch_assoc()) {
                                @endphp
                                <tr class="table-light">
                                    <td>
                                        <h6>
                                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">
                                                <h6>{{ $strow['TopicName'] }}</h6>
                                            </a>
                                        </h6>

                                    </td>
                                    <td>
                                        <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">
                                            <h6>{{ $strow['PageAssoc'] }}</h6>
                                        </a>
                                    </td>

                                </tr>
                                @php
                                    }
                                @endphp
                                </tbody>
                            </table>
                            {{--                @foreach ($book_chapter_topics as $tkey => $trow)--}}
                            {{--                    {{ $trow->TopicName }}--}}
                            {{--                @endforeach--}}
                        </td>

                        <td>
                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                                {{$row->PageAssoc}}
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <div class="col-md-9">
            <div class="mt-3">
                <h6>کل صفحات: {{ $page_count }}</h6>
            </div>
            @foreach($book_pages as $key => $row)
                <div class="card border border-success">
                    <div class="card-header bg-dark text-white border border-info">
                        <div class="col-md-12">
                            <div class="col-md-4 d-inline-block float-start">
                                <span id="p{{ $row->PageNo }}"></span>
                                <h4 class="card-title mt-3">{{ $row->BookTitle }}</h4>
                            </div>
                            <div class="col-md-4 d-inline-block align-self-center">
                                <h3 class="card-title text-center mt-3">
                                    <i class="bi bi-book-half"></i>
                                </h3>
                            </div>
                            <div class="col-md-4 d-inline-block float-end">
                                <h6 class="card-title float-end mt-3">{- {{ $row->PageTitle }} -}</h6>
                            </div>
                        </div>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body py-0">
                        {{--                            <div class="mb-3">--}}
                        {{--                                <p class="float-start d-inline-block">----------</p>--}}
                        {{--                                <p class="float-end d-inline-block">------------</p>--}}
                        {{--                            </div>--}}
                        <div class="card-text" style="font-size: 1.2em; line-height: 2.5em; word-spacing: 0.1em;">
                            {!! $row->PageContent !!}
                        </div>
                        <div class="text-center">
                            <div class="d-inline-block p-2 border border-1 rounded-pill">
                                صفحہ نمبر: {{ $row->PageNo }}
                            </div>
                        </div>
                    </div> <!-- /.card-body -->
                    <div class="card-footer text-muted text-center">
                        <div class="text-start">
                            {!! $row->PageHashiyah !!}
                        </div>
                    </div>
                </div> <!-- /.card -->
                <span class="mb-1">&nbsp;</span>
            @endforeach
        </div>
    </div>
    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="bi bi-arrow-up-square"></i></button>

@endsection
