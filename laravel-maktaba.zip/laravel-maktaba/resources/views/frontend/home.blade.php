@extends('frontend.master')

@section('content')
{{--    {{ printArray($contents->toArray())  }}--}}
@endsection
