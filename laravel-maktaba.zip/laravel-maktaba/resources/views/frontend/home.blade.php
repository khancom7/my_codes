@extends('frontend.master')

@section('content')
{{--    {{ printArray($book_pages->toArray())  }}--}}
<div class="col-md-12 align-items-center">
    <div class="card">
        <div class="card-header">
            <h1 class="card-title text-center" style="font-family: myCustomUrduFont3; font-size: 5em;">مکتبہ ختم نبوت</h1>
        </div>
        <div class="card-body table-responsive">
            <h5 class="card-title">ختم نبوت کی کتابیں یونی کوڈ میں</h5>
            <hr>
            <div class="row">
                {{ $books->links() }}
            </div>
            <table class="table table-hover text-nowrap" style="font-size: 0.9em;">
                <thead>
                <tr>
{{--                    <th>Number</th>--}}
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                @foreach($books as $key => $row)
                    <tr>
{{--                        <td>{{ $key+1 }}</td>--}}
                        <td>
                            <a href="{{url('book/open/'.$row->BookID)}}" style="text-decoration: none;">
                                {{$row->BookTitle}}
                            </a>
                        </td>
                        <td>{{$row->BookAuthor}}</td>
                        <td>
                            <a href="{{url('book/open/'.$row->BookID)}}" class="btn btn-outline-primary float-start me-3 mb-2">کھولیں</a>

                            <a href="{{url('book/index/'.$row->BookID)}}" class="btn btn-outline-primary float-start">فہرست</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>


@endsection
