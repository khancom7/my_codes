@extends('frontend.master')

{{--@php--}}
{{--        printArray($book_name);die;--}}
{{--@endphp--}}

@section('content')

    <div>
        <h3>تلاش: </h3>
        <h3>{{ $search_text }}</h3>
    </div>
<table class="table table-bordered data-table">
    <thead>
    <tr>
        <th>Page No</th>
        <th>Book</th>
        <th>Text</th>
    </tr>
    </thead>
    <tbody>
    @foreach ($pages as $key => $page)
        <tr>
            <td>{{ $page->PageNo }}</td>
            <td>{{ $book_name[$key]->BookTitle }}</td>
            <td>
                <a class="text-decoration-none" href="/book/open/{{ $page->BookID }}#p{{ $page->PageNo }}">
                    {!! Str::limit($page->PageContent, 95) !!}
                </a>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

@endsection
