@extends('frontend.master')

{{--@php--}}
{{--        printArray($book_name);die;--}}
{{--@endphp--}}

@section('content')

    <div>
        <h3>تلاش: </h3>
        <h3>{{ $search_text }}</h3>
    </div>
<table class="table table-bordered data-table">
    <thead>
    <tr>
        <th>کتاب</th>
        <th>تحریر</th>
        <th>صفحہ نمبر</th>
    </tr>
    </thead>
    <tbody>
    @foreach ($pages as $key => $page)
        <tr>
            <td>{{ $book_name[$key]->BookTitle }}</td>
            <td>
                <a class="text-decoration-none" href="/book/open/{{ $page->BookID }}#p{{ $page->PageNo }}">
                    {!! Str::limit($page->PageContent, 95) !!}
                </a>
            </td>
            <td>{{ $page->PageNo }}</td>
        </tr>
    @endforeach
    </tbody>
</table>

@endsection
