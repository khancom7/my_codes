@extends('frontend.master')

@section('content')
{{--        {{ printArray($book_chapters->toArray())  }}--}}
<table class="table table-responsive">
    <thead>
    <tr>
        <th scope="col">نمبر</th>
        <th scope="col">عنوان</th>
        <th scope="col">صفحہ نمبر</th>
    </tr>
    </thead>
    <tbody>
    @foreach($book_index as $key => $row)
        <tr class="table-info">
            {{--                        <td>{{ $key+1 }}</td>--}}
            <td>{{$row->ChapterNo}}</td>
            <td>
                <h4>
                    <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                        {{$row->ChapterName}}
                    </a>
                </h4>
                <table class="table table-responsive">
                    <thead>
                    <th></th>
                    <th></th>
                    </thead>
                    <tbody>
                @php
                    $sql = "SELECT * FROM `book_chapter_topics` WHERE  `ChapterID` = ". $row->ChapterID;
                                       $result = mysqlConn($sql);
                       while($strow = $result->fetch_assoc()) {
                            @endphp
                    <tr class="table-success">
                        <td>
                            <h5>
                                <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">
                                    <h6>{{ $strow['TopicName'] }}</h6>
                                </a>
                            </h5>

                        </td>
                        <td>
                            <a href="{{url('book/open/'.$row->BookID)}}#p{{ $strow['PageAssoc'] }}">
                                <h6>{{ $strow['PageAssoc'] }}</h6>
                            </a>
                        </td>

                    </tr>
                @php
						}
                @endphp
                    </tbody>
                </table>
{{--                @foreach ($book_chapter_topics as $tkey => $trow)--}}
{{--                    {{ $trow->TopicName }}--}}
{{--                @endforeach--}}
            </td>

            <td>
                <a href="{{url('book/open/'.$row->BookID)}}#p{{ $row->PageAssoc }}" style="text-decoration: none;">
                    {{$row->PageAssoc}}
                </a>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

@endsection
