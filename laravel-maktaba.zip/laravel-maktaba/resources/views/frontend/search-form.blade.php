@extends('frontend.master')

@php
//    printArray($pages);die;
@endphp

@section('content')
    <div class="container mt-5">
        <h2 class="text-center">Scout Text Search</h2>
        <form method="get" action="{{ route('search') }}">
            <div class="mb-3">
                <label for="search"class="form-label">Email address</label>

                <input type="text"
                       class="form-control"
                       name="search"
                       value="{{ request()->get('search') }}"
                       placeholder="Search Text" />
                <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

    </div>
@endsection
